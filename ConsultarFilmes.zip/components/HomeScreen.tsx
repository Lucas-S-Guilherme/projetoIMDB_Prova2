import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import axios from 'axios';

type Movie = {
  id: number;
  title: string;
  poster_path?: string;
  release_date: string;
  vote_average: number;
  overview: string;
};

const { width } = Dimensions.get('window');

const HomeScreen: React.FC = () => {
  const [featuredMovie, setFeaturedMovie] = useState<Movie | null>(null);
  const [upcomingMovies, setUpcomingMovies] = useState<Movie[]>([]);
  const [topRatedMovies, setTopRatedMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        // Busca o filme em destaque (o primeiro filme popular)
        const popularResponse = await axios.get('https://api.themoviedb.org/3/movie/popular', {
          params: {
            api_key: process.env.EXPO_PUBLIC_TMDB_API_KEY,
            language: 'pt-BR',
            page: 1,
          },
        });
        setFeaturedMovie(popularResponse.data.results[0]);

        // Busca os próximos lançamentos
        const upcomingResponse = await axios.get('https://api.themoviedb.org/3/movie/upcoming', {
          params: {
            api_key: process.env.EXPO_PUBLIC_TMDB_API_KEY,
            language: 'pt-BR',
            page: 1,
          },
        });
        setUpcomingMovies(upcomingResponse.data.results);

        // Busca os mais bem avaliados
        const topRatedResponse = await axios.get('https://api.themoviedb.org/3/movie/top_rated', {
          params: {
            api_key: process.env.EXPO_PUBLIC_TMDB_API_KEY,
            language: 'pt-BR',
            page: 1,
          },
        });
        setTopRatedMovies(topRatedResponse.data.results);
      } catch (error) {
        console.error('Erro ao buscar filmes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMovies();
  }, []);

  if (loading) {
    return <ActivityIndicator size="large" color="#0000ff" style={styles.loader} />;
  }

  return (
    <ScrollView style={styles.container}>
      {/* Seção Em Destaque */}
      {featuredMovie && (
        <View style={styles.featuredContainer}>
          <Image
            source={{ uri: `https://image.tmdb.org/t/p/w500${featuredMovie.poster_path}` }}
            style={styles.featuredImage}
          />
          <View style={styles.featuredDetails}>
            <Text style={styles.featuredTitle}>{featuredMovie.title}</Text>
            <Text style={styles.featuredYear}>{featuredMovie.release_date.split('-')[0]}</Text>
            <Text style={styles.featuredOverview} numberOfLines={3}>
              {featuredMovie.overview}
            </Text>
            <TouchableOpacity style={styles.featuredButton}>
              <Text style={styles.featuredButtonText}>Assistir</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Seção Próximos Lançamentos */}
      <Text style={styles.sectionTitle}>Próximos Lançamentos</Text>
      <FlatList
        data={upcomingMovies}
        horizontal
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.upcomingMovie}>
            <Image
              source={{ uri: `https://image.tmdb.org/t/p/w200${item.poster_path}` }}
              style={styles.upcomingImage}
            />
            <Text style={styles.upcomingTitle}>{item.title}</Text>
            <Text style={styles.upcomingRating}>⭐ {item.vote_average.toFixed(1)}</Text>
          </View>
        )}
        contentContainerStyle={styles.upcomingList}
      />

      {/* Seção Mais Bem Avaliados */}
      <Text style={styles.sectionTitle}>Mais Bem Avaliados</Text>
      <FlatList
        data={topRatedMovies}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.topRatedMovie}>
            <Image
              source={{ uri: `https://image.tmdb.org/t/p/w200${item.poster_path}` }}
              style={styles.topRatedImage}
            />
            <View style={styles.topRatedDetails}>
              <Text style={styles.topRatedTitle}>{item.title}</Text>
              <Text style={styles.topRatedRating}>⭐ {item.vote_average.toFixed(1)}</Text>
            </View>
          </View>
        )}
        contentContainerStyle={styles.topRatedList}
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1c1c1c',
    padding: 16,
  },
  loader: {
    marginTop: 20,
  },
  featuredContainer: {
    marginBottom: 24,
  },
  featuredImage: {
    width: '100%',
    height: 300,
    borderRadius: 12,
  },
  featuredDetails: {
    marginTop: 16,
  },
  featuredTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  featuredYear: {
    fontSize: 16,
    color: '#888',
    marginTop: 8,
  },
  featuredOverview: {
    fontSize: 14,
    color: '#ccc',
    marginTop: 8,
  },
  featuredButton: {
    backgroundColor: '#e50914',
    padding: 12,
    borderRadius: 8,
    marginTop: 16,
    alignItems: 'center',
  },
  featuredButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 16,
  },
  upcomingList: {
    paddingBottom: 16,
  },
  upcomingMovie: {
    width: 120,
    marginRight: 16,
  },
  upcomingImage: {
    width: 120,
    height: 180,
    borderRadius: 8,
  },
  upcomingTitle: {
    fontSize: 14,
    color: '#fff',
    marginTop: 8,
  },
  upcomingRating: {
    fontSize: 12,
    color: '#888',
    marginTop: 4,
  },
  topRatedList: {
    paddingBottom: 16,
  },
  topRatedMovie: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  topRatedImage: {
    width: 80,
    height: 120,
    borderRadius: 8,
  },
  topRatedDetails: {
    flex: 1,
    marginLeft: 16,
    justifyContent: 'center',
  },
  topRatedTitle: {
    fontSize: 16,
    color: '#fff',
  },
  topRatedRating: {
    fontSize: 14,
    color: '#888',
    marginTop: 4,
  },
});

export default HomeScreen;